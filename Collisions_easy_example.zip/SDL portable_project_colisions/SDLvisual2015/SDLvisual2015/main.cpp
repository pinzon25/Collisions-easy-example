#include <iostream>
#include "include/SDL.h"
#pragma comment( lib, "SDL/lib/x86/SDL2.lib")
#pragma comment( lib, "SDL/lib/x86/SDL2main.lib")


bool collision(SDL_Rect* rect2, SDL_Rect* rect) {

	if (rect->y >= rect2->y + rect2->h) {
		return 0;
	}

	if (rect->x >= rect2->x + rect2->h) {
		return 0;
	}

	if (rect->y + rect->h <= rect2->y) {
		return 0;
	}

	if (rect->x + rect->w <= rect2->x) {
		return 0;
	}

	return 1;

}


int main(int argc, char* args[]) {

	

	SDL_Window* Window;
	SDL_Renderer* renderer ;
	SDL_Rect rect, rect2;
	SDL_Event event;
	bool running = true;
	bool up = false;
	bool right = false;
	bool left = false;
	bool down = false;
	

	SDL_Init(SDL_INIT_EVERYTHING);

	if (SDL_Init(SDL_INIT_VIDEO) < 0) return 1;

		Window = SDL_CreateWindow("Chapter 1", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 480, SDL_WINDOW_SHOWN);
		renderer = SDL_CreateRenderer(Window, -1, SDL_RENDERER_PRESENTVSYNC);
		
		
		rect.x = 50;
		rect.y = 50;
		rect.w = 50;
		rect.h = 50;

		rect2.x = 120;
		rect2.y = 120;
		rect2.w = 200;
		rect2.h = 200;


		while (running) {
			

			if (SDL_PollEvent(&event)) {

				if(event.type == SDL_KEYDOWN){  
				
						switch (event.key.keysym.sym) {
							
						case SDLK_ESCAPE:
							running = false;
							break;

						case SDLK_UP:
							up = true;
							break;

						case SDLK_DOWN:							
							down = true;
							break;

						case SDLK_LEFT:							
							left = true;							
							break;

						case SDLK_RIGHT:							
							right = true;
							break;
						default:
							break;

						}
					}

				if (event.type == SDL_KEYUP) {

					switch (event.key.keysym.sym) {
	
					case SDLK_UP:
						up = false;
						break;

					case SDLK_DOWN:
						down = false;
						break;

					case SDLK_LEFT:
						left = false;
						break;

					case SDLK_RIGHT:
						right = false;
						break;
					default:
						break;
					}
				}
			}	
			
			

			/*Movement of the main rectangle*/

			
			if (up) {
				rect.y -= 5;
				if (collision(&rect2, &rect))
					rect.y += 5;
			}
			

			if (down) {
				rect.y += 5;
				if (collision(&rect2, &rect))
					rect.y -= 5;
			}
			


			if (left) {
				rect.x -= 5;
				if (collision(&rect2, &rect))
					rect.x += 5;
			}
			


			if (right) {
				rect.x += 5;
				if (collision(&rect2, &rect))
					rect.x -= 5;
			}
			
				
			
			SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
			SDL_RenderClear(renderer);


			    /*Main Rectangle*/
				SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
				SDL_RenderFillRect(renderer, &rect);

				/*2nd rectangle*/
				SDL_RenderFillRect(renderer, &rect2);
				SDL_RenderPresent(renderer);
			
    
		}
	
	SDL_Quit();
	return EXIT_SUCCESS;
}



